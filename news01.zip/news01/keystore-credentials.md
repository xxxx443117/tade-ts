# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution.

## Credential Values

- Android keystore password: 12eb36fcc3ae451adabfc4806c93f2e2
- Android key alias: 5c87ef47328f74366fac56b9b655e4a9
- Android key password: ba0cfc73d5675ac8d530205dec4d8ab1

# FACEBOOK

"appID": "950610639454869",
"clientToken": "ac20d3906319e57eee63f4d3738d20f2",
"displayName": "24H Notícias",
"scheme": "fb950610639454869",

# APP

bundle id
com.daytrade.news01
